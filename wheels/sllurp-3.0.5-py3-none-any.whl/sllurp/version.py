"""Sllurp version info"""

__version__ = "3.0.5"
